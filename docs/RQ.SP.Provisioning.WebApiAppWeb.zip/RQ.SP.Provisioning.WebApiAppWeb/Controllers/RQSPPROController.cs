﻿using Microsoft.Online.SharePoint.TenantAdministration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace RQ.SP.Provisioning.WebApiAppWeb.Controllers
{

    [EnableCors(origins: "https://localhost:5001/,https://localhost:44382/",
        headers: "*",
        methods: "*",
        SupportsCredentials = false)]
    [SharePointApiControllerContextFilterAttribute]

    public class RQSPPROController : ApiController
    {
        [SharePointApiControllerContextFilter]
        [HttpGet]
        public IHttpActionResult CreateSite(string siteName)
        {

            var spContext = SharePointApiControllerContextProvider.Current.GetSharePointContext(ControllerContext);
           using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                SiteCreationProperties _siteinfos = new SiteCreationProperties();
                var spUser = clientContext.Web.CurrentUser;
                try
                {
                    clientContext.Load(spUser, user => user.LoginName);
                    clientContext.ExecuteQuery();
                     Tenant tenant = new Tenant(clientContext);
                    _siteinfos.Url = "http://collaboration.portail.rq/themes/mika" + siteName.ToString();
                    _siteinfos.Template = "BLANKINTERNET#0";
                    _siteinfos.Lcid = 1036;
                    _siteinfos.Title = "mika" + siteName.ToString();
                    _siteinfos.Owner = spUser.LoginName;
                    SpoOperation op = tenant.CreateSite(_siteinfos);
                    clientContext.Load(op, operation => operation.IsComplete);
                    clientContext.ExecuteQuery();
                    Created("", "");
                    return Ok("Done Create Site : http://collaboration.portail.rq/themes/mika" + siteName.ToString());
                }
                catch (Exception ex)
                {
                    return Ok("NOk");
                }


               
            }
        }
    }
}
