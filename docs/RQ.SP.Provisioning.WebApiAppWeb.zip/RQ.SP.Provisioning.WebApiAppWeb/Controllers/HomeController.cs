﻿using Microsoft.SharePoint.Client;
using OfficeDevPnP.Core.WebAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RQ.SP.Provisioning.WebApiAppWeb.Controllers
{
    public class HomeController : Controller
    {
        [SharePointContextFilter]
        public ActionResult Index()
        {
            User spUser = null;

            var spContext = SharePointContextProvider.Current.GetSharePointContext(HttpContext);

            using (var clientContext = spContext.CreateUserClientContextForSPHost())
            {
                if (clientContext != null)
                {
                    Register();
                    spUser = clientContext.Web.CurrentUser;

                    clientContext.Load(spUser, user => user.Title);

                    clientContext.ExecuteQuery();

                    ViewBag.UserName = spUser.Title;
                }
            }

            return View();
        }

        [SharePointApiControllerContextFilter]
        public ActionResult Register()
        {
            try
            {
                
                // Register the BusinessDocuments API
                WebAPIHelper.RegisterWebAPIService(this.HttpContext, "/api/BusinessDocuments");
                return Json(new { message = "Web API registered" });
            }
            catch (Exception ex)
            {
                return Json(ex);
            }
        }


    }
}
