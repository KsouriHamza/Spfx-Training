﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace RQ.SP.Provisioning.WebApiAppWeb
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {

            // TO USE THIS CODE YOU NEED  install Install-Package Microsoft.AspNet.Odata

            //ODataModelBuilder builder = new ODataConventionModelBuilder();
            //builder.EntitySet<Product>("Products");
            //config.MapODataServiceRoute(
            //    routeName: "ODataRoute",
            //    routePrefix: null,
            //    model: builder.GetEdmModel());
            // Web API configuration and services

            config.EnableCors();
            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{siteName}",
                defaults: new { siteName = RouteParameter.Optional }
            );
        }
    }
}